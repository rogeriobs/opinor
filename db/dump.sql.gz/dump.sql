--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.12
-- Dumped by pg_dump version 9.5.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: admin_menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_menu (
    id integer NOT NULL,
    descricao character varying(100) NOT NULL,
    ordem integer,
    faicon character varying(50) NOT NULL,
    created timestamp without time zone,
    modified timestamp without time zone
);


ALTER TABLE public.admin_menu OWNER TO postgres;

--
-- Name: TABLE admin_menu; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.admin_menu IS 'Menus do Admin';


--
-- Name: admin_menu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.admin_menu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_menu_id_seq OWNER TO postgres;

--
-- Name: admin_menu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.admin_menu_id_seq OWNED BY public.admin_menu.id;


--
-- Name: admin_menu_itens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_menu_itens (
    id integer NOT NULL,
    admin_menu_id integer NOT NULL,
    descricao character varying(100) NOT NULL,
    ordem integer,
    action_perm character varying(100) NOT NULL,
    params character varying,
    created timestamp without time zone,
    modified timestamp without time zone,
    controller_go character varying(100) NOT NULL,
    action_go character varying(100) NOT NULL
);


ALTER TABLE public.admin_menu_itens OWNER TO postgres;

--
-- Name: TABLE admin_menu_itens; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.admin_menu_itens IS 'Itens do menu administrativo';


--
-- Name: admin_menu_itens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.admin_menu_itens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_menu_itens_id_seq OWNER TO postgres;

--
-- Name: admin_menu_itens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.admin_menu_itens_id_seq OWNED BY public.admin_menu_itens.id;


--
-- Name: cidades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cidades (
    id integer NOT NULL,
    nome character varying(120) NOT NULL,
    estado_id integer NOT NULL,
    codigo_ibge integer NOT NULL
);


ALTER TABLE public.cidades OWNER TO postgres;

--
-- Name: dominus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dominus (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    username character varying(100) NOT NULL,
    password character varying NOT NULL,
    shutoff boolean DEFAULT false NOT NULL,
    dominus_perfil_id integer NOT NULL
);


ALTER TABLE public.dominus OWNER TO postgres;

--
-- Name: dominus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dominus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dominus_id_seq OWNER TO postgres;

--
-- Name: dominus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dominus_id_seq OWNED BY public.dominus.id;


--
-- Name: dominus_perfis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dominus_perfis (
    id integer NOT NULL,
    descricao character varying NOT NULL,
    role character(1) DEFAULT 'U'::bpchar NOT NULL,
    permissoes json DEFAULT '{}'::json NOT NULL,
    created timestamp without time zone,
    modified timestamp without time zone
);


ALTER TABLE public.dominus_perfis OWNER TO postgres;

--
-- Name: TABLE dominus_perfis; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.dominus_perfis IS 'Perfil dos usuarios administrativos';


--
-- Name: COLUMN dominus_perfis.role; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dominus_perfis.role IS 'R = root; S = Super usuario, U = Usuario comum';


--
-- Name: dominus_perfis_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dominus_perfis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dominus_perfis_id_seq OWNER TO postgres;

--
-- Name: dominus_perfis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dominus_perfis_id_seq OWNED BY public.dominus_perfis.id;


--
-- Name: estados; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estados (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    uf character(2) NOT NULL,
    uf_ibge smallint NOT NULL,
    uf_sl smallint NOT NULL,
    uf_ddd character varying(60) NOT NULL,
    regiao character varying(60) NOT NULL
);


ALTER TABLE public.estados OWNER TO postgres;

--
-- Name: ipsum; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipsum (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    password character varying(255) NOT NULL,
    status character(1) NOT NULL,
    data_nascimento date NOT NULL,
    cidade_id integer NOT NULL,
    created timestamp without time zone,
    modified timestamp without time zone
);


ALTER TABLE public.ipsum OWNER TO postgres;

--
-- Name: ipsum_activate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipsum_activate (
    ipsum_id integer NOT NULL,
    token character varying(200),
    expiration_date date NOT NULL,
    created timestamp without time zone,
    modified timestamp without time zone
);


ALTER TABLE public.ipsum_activate OWNER TO postgres;

--
-- Name: ipsum_activate_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ipsum_activate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ipsum_activate_id_seq OWNER TO postgres;

--
-- Name: ipsum_activate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ipsum_activate_id_seq OWNED BY public.ipsum_activate.ipsum_id;


--
-- Name: ipsum_activity_access_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipsum_activity_access_logs (
    id bigint NOT NULL,
    ipsum_id integer NOT NULL,
    newsortopic_id integer NOT NULL,
    ip character varying(100) NOT NULL,
    created timestamp without time zone NOT NULL
);


ALTER TABLE public.ipsum_activity_access_logs OWNER TO postgres;

--
-- Name: ipsum_activity_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ipsum_activity_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ipsum_activity_log_id_seq OWNER TO postgres;

--
-- Name: ipsum_activity_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ipsum_activity_log_id_seq OWNED BY public.ipsum_activity_access_logs.id;


--
-- Name: ipsum_activity_search_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipsum_activity_search_logs (
    id bigint NOT NULL,
    ip character varying(100) NOT NULL,
    termo character varying(40) NOT NULL,
    created timestamp without time zone NOT NULL,
    ipsum_id integer
);


ALTER TABLE public.ipsum_activity_search_logs OWNER TO postgres;

--
-- Name: ipsum_activity_search_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ipsum_activity_search_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ipsum_activity_search_logs_id_seq OWNER TO postgres;

--
-- Name: ipsum_activity_search_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ipsum_activity_search_logs_id_seq OWNED BY public.ipsum_activity_search_logs.id;


--
-- Name: ipsum_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ipsum_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ipsum_id_seq OWNER TO postgres;

--
-- Name: ipsum_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ipsum_id_seq OWNED BY public.ipsum.id;


--
-- Name: ipsum_recovery_password; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipsum_recovery_password (
    codigo character varying(300) NOT NULL,
    ipsum_id integer NOT NULL,
    validade_do_link date NOT NULL,
    created timestamp without time zone NOT NULL
);


ALTER TABLE public.ipsum_recovery_password OWNER TO postgres;

--
-- Name: newsortopic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.newsortopic (
    id integer NOT NULL,
    titulo character varying(140) NOT NULL,
    alias character varying(200) NOT NULL,
    data_de_publicacao timestamp without time zone NOT NULL,
    data_da_fonte timestamp without time zone NOT NULL,
    texto_resumo character varying(300) NOT NULL,
    texto_full text NOT NULL,
    meta_title character varying(200),
    meta_description text,
    meta_keywords character varying(200),
    shutoff boolean DEFAULT false NOT NULL,
    poll_id integer,
    format_article character varying(10) NOT NULL,
    created timestamp without time zone,
    modified timestamp without time zone,
    dominus_id integer NOT NULL,
    fonte character varying(100),
    fonte_link character varying(255),
    destaque_ordem integer
);


ALTER TABLE public.newsortopic OWNER TO postgres;

--
-- Name: newsortopic_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.newsortopic_comments (
    id integer NOT NULL,
    newsortopic_id integer NOT NULL,
    ipsum_id integer NOT NULL,
    comentario character varying(400) NOT NULL,
    data_e_hora timestamp without time zone NOT NULL,
    status character(1) NOT NULL
);


ALTER TABLE public.newsortopic_comments OWNER TO postgres;

--
-- Name: COLUMN newsortopic_comments.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.newsortopic_comments.status IS 'status do cometario: 0 = inativo; 1 = ativo; 2 = bloqueado';


--
-- Name: newsortopic_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.newsortopic_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.newsortopic_comments_id_seq OWNER TO postgres;

--
-- Name: newsortopic_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.newsortopic_comments_id_seq OWNED BY public.newsortopic_comments.id;


--
-- Name: newsortopic_comments_rating; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.newsortopic_comments_rating (
    ipsum_id integer NOT NULL,
    newsortopic_comments_id integer NOT NULL,
    type character(1) NOT NULL
);


ALTER TABLE public.newsortopic_comments_rating OWNER TO postgres;

--
-- Name: COLUMN newsortopic_comments_rating.type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.newsortopic_comments_rating.type IS '1 = like, 2 = notlike, 3 = maybe';


--
-- Name: newsortopic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.newsortopic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.newsortopic_id_seq OWNER TO postgres;

--
-- Name: newsortopic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.newsortopic_id_seq OWNED BY public.newsortopic.id;


--
-- Name: newsortopic_imagens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.newsortopic_imagens (
    id integer NOT NULL,
    filename character varying(200) NOT NULL,
    head boolean DEFAULT false NOT NULL,
    legenda character varying(100),
    real_width character varying(10) NOT NULL,
    real_height character varying(10) NOT NULL,
    use_width character varying(10) NOT NULL,
    use_height character varying(10) NOT NULL,
    newsortopic_id integer NOT NULL
);


ALTER TABLE public.newsortopic_imagens OWNER TO postgres;

--
-- Name: newsortopic_imagens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.newsortopic_imagens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.newsortopic_imagens_id_seq OWNER TO postgres;

--
-- Name: newsortopic_imagens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.newsortopic_imagens_id_seq OWNED BY public.newsortopic_imagens.id;


--
-- Name: newsortopic_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.newsortopic_tags (
    newsortopic_id integer NOT NULL,
    tag character varying(70) NOT NULL
);


ALTER TABLE public.newsortopic_tags OWNER TO postgres;

--
-- Name: poll; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.poll (
    id integer NOT NULL,
    titulo character varying(140) NOT NULL,
    shutoff boolean DEFAULT false NOT NULL,
    expiration_date date,
    created timestamp without time zone,
    modified timestamp without time zone
);


ALTER TABLE public.poll OWNER TO postgres;

--
-- Name: poll_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.poll_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.poll_id_seq OWNER TO postgres;

--
-- Name: poll_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.poll_id_seq OWNED BY public.poll.id;


--
-- Name: poll_options; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.poll_options (
    id integer NOT NULL,
    label_text character varying(100) NOT NULL,
    poll_id integer NOT NULL,
    created timestamp without time zone,
    modified timestamp without time zone,
    ordem smallint DEFAULT 0 NOT NULL
);


ALTER TABLE public.poll_options OWNER TO postgres;

--
-- Name: poll_options_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.poll_options_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.poll_options_id_seq OWNER TO postgres;

--
-- Name: poll_options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.poll_options_id_seq OWNED BY public.poll_options.id;


--
-- Name: poll_options_votes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.poll_options_votes (
    ipsum_id integer NOT NULL,
    poll_options_id integer NOT NULL,
    created timestamp without time zone,
    modified timestamp without time zone,
    poll_id integer NOT NULL,
    ip character varying(15) NOT NULL
);


ALTER TABLE public.poll_options_votes OWNER TO postgres;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_menu ALTER COLUMN id SET DEFAULT nextval('public.admin_menu_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_menu_itens ALTER COLUMN id SET DEFAULT nextval('public.admin_menu_itens_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dominus ALTER COLUMN id SET DEFAULT nextval('public.dominus_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dominus_perfis ALTER COLUMN id SET DEFAULT nextval('public.dominus_perfis_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipsum ALTER COLUMN id SET DEFAULT nextval('public.ipsum_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipsum_activity_access_logs ALTER COLUMN id SET DEFAULT nextval('public.ipsum_activity_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipsum_activity_search_logs ALTER COLUMN id SET DEFAULT nextval('public.ipsum_activity_search_logs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic ALTER COLUMN id SET DEFAULT nextval('public.newsortopic_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic_comments ALTER COLUMN id SET DEFAULT nextval('public.newsortopic_comments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic_imagens ALTER COLUMN id SET DEFAULT nextval('public.newsortopic_imagens_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll ALTER COLUMN id SET DEFAULT nextval('public.poll_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_options ALTER COLUMN id SET DEFAULT nextval('public.poll_options_id_seq'::regclass);


--
-- Name: admin_menu_itens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_menu_itens
    ADD CONSTRAINT admin_menu_itens_pkey PRIMARY KEY (id);


--
-- Name: admin_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_menu
    ADD CONSTRAINT admin_menu_pkey PRIMARY KEY (id);


--
-- Name: cidades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cidades
    ADD CONSTRAINT cidades_pkey PRIMARY KEY (id);


--
-- Name: dominus_perfis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dominus_perfis
    ADD CONSTRAINT dominus_perfis_pkey PRIMARY KEY (id);


--
-- Name: estados_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estados
    ADD CONSTRAINT estados_pkey1 PRIMARY KEY (id);


--
-- Name: ipsum_activate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipsum_activate
    ADD CONSTRAINT ipsum_activate_pkey PRIMARY KEY (ipsum_id);


--
-- Name: ipsum_activate_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipsum_activate
    ADD CONSTRAINT ipsum_activate_token_key UNIQUE (token);


--
-- Name: ipsum_activity_search_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipsum_activity_search_logs
    ADD CONSTRAINT ipsum_activity_search_logs_pkey PRIMARY KEY (id);


--
-- Name: ipsum_recovery_password_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipsum_recovery_password
    ADD CONSTRAINT ipsum_recovery_password_pkey PRIMARY KEY (codigo);


--
-- Name: pkey_accesslog; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipsum_activity_access_logs
    ADD CONSTRAINT pkey_accesslog PRIMARY KEY (id);


--
-- Name: pkey_commentsid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic_comments
    ADD CONSTRAINT pkey_commentsid PRIMARY KEY (id);


--
-- Name: pkey_comp_idpolloptvoteidipsum; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_options_votes
    ADD CONSTRAINT pkey_comp_idpolloptvoteidipsum PRIMARY KEY (ipsum_id, poll_options_id);


--
-- Name: pkey_comp_notnotrating; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic_comments_rating
    ADD CONSTRAINT pkey_comp_notnotrating PRIMARY KEY (ipsum_id, newsortopic_comments_id);


--
-- Name: pkey_dominusid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dominus
    ADD CONSTRAINT pkey_dominusid PRIMARY KEY (id);


--
-- Name: pkey_idimagensdonewsortopic; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic_imagens
    ADD CONSTRAINT pkey_idimagensdonewsortopic PRIMARY KEY (id);


--
-- Name: pkey_ipsumid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipsum
    ADD CONSTRAINT pkey_ipsumid PRIMARY KEY (id);


--
-- Name: pkey_newsortopicid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic
    ADD CONSTRAINT pkey_newsortopicid PRIMARY KEY (id);


--
-- Name: pkey_newsortopictags_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic_tags
    ADD CONSTRAINT pkey_newsortopictags_id PRIMARY KEY (newsortopic_id, tag);


--
-- Name: pkey_pollid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll
    ADD CONSTRAINT pkey_pollid PRIMARY KEY (id);


--
-- Name: pkey_polloptionsid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_options
    ADD CONSTRAINT pkey_polloptionsid PRIMARY KEY (id);


--
-- Name: punique_alias_newsortopic; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic
    ADD CONSTRAINT punique_alias_newsortopic UNIQUE (alias);


--
-- Name: punique_ipsum_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipsum
    ADD CONSTRAINT punique_ipsum_email UNIQUE (email);


--
-- Name: punique_unicavotacaonaenquete; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_options_votes
    ADD CONSTRAINT punique_unicavotacaonaenquete UNIQUE (poll_id, ipsum_id);


--
-- Name: key_idipsumid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX key_idipsumid ON public.ipsum_activity_access_logs USING btree (ipsum_id);


--
-- Name: fk_adminmenuid_adminitens; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_menu_itens
    ADD CONSTRAINT fk_adminmenuid_adminitens FOREIGN KEY (admin_menu_id) REFERENCES public.admin_menu(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_dominusid_newsortopic; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic
    ADD CONSTRAINT fk_dominusid_newsortopic FOREIGN KEY (dominus_id) REFERENCES public.dominus(id) MATCH FULL;


--
-- Name: fk_enqueteid_votes_restricao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_options_votes
    ADD CONSTRAINT fk_enqueteid_votes_restricao FOREIGN KEY (poll_id) REFERENCES public.poll(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: fk_estadosid_cidades; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cidades
    ADD CONSTRAINT fk_estadosid_cidades FOREIGN KEY (estado_id) REFERENCES public.estados(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_imagensdonewsortopic; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic_imagens
    ADD CONSTRAINT fk_imagensdonewsortopic FOREIGN KEY (newsortopic_id) REFERENCES public.newsortopic(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_ipsum_cidadeid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipsum
    ADD CONSTRAINT fk_ipsum_cidadeid FOREIGN KEY (cidade_id) REFERENCES public.cidades(id);


--
-- Name: fk_ipsumid_activateid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipsum_activate
    ADD CONSTRAINT fk_ipsumid_activateid FOREIGN KEY (ipsum_id) REFERENCES public.ipsum(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_ipsumid_comments; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic_comments
    ADD CONSTRAINT fk_ipsumid_comments FOREIGN KEY (ipsum_id) REFERENCES public.ipsum(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_ipsumid_neortocoraid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic_comments_rating
    ADD CONSTRAINT fk_ipsumid_neortocoraid FOREIGN KEY (ipsum_id) REFERENCES public.ipsum(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_ipsumid_votepollopt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_options_votes
    ADD CONSTRAINT fk_ipsumid_votepollopt FOREIGN KEY (ipsum_id) REFERENCES public.ipsum(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_neortocoid_notcrid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic_comments_rating
    ADD CONSTRAINT fk_neortocoid_notcrid FOREIGN KEY (newsortopic_comments_id) REFERENCES public.newsortopic_comments(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_newsortopic_pollid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic
    ADD CONSTRAINT fk_newsortopic_pollid FOREIGN KEY (poll_id) REFERENCES public.poll(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_newsortopicid_comments; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic_comments
    ADD CONSTRAINT fk_newsortopicid_comments FOREIGN KEY (newsortopic_id) REFERENCES public.newsortopic(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_newsortopicid_tags; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.newsortopic_tags
    ADD CONSTRAINT fk_newsortopicid_tags FOREIGN KEY (newsortopic_id) REFERENCES public.newsortopic(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_poll_id_options; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_options
    ADD CONSTRAINT fk_poll_id_options FOREIGN KEY (poll_id) REFERENCES public.poll(id) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_polloptionsid_votes; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_options_votes
    ADD CONSTRAINT fk_polloptionsid_votes FOREIGN KEY (poll_options_id) REFERENCES public.poll_options(id) MATCH FULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

